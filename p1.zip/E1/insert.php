
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informatiom Form</title>
</head>
<body>


<div style="text-align:center;background-color:#cdcdcd">
<form action="insertdata.php" method="post">
  

 Name:    <input type="text" name="Firstname"   > <br><br>
 Surname: <input type="text" name="Surname"    > <br><br>
 E-mail:  <input type="text" name="Email"       > <br><br>
 P-number: <input type="text" name="Phone"     > <br><br>

 <input type="submit" name="save" value="Send">

</form>
</div>






</body>
</html>
